---
name: Botanical Heritage
colors:
  surface: '#faf9f5'
  surface-dim: '#dbdad6'
  surface-bright: '#faf9f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f4f0'
  surface-container: '#efeeea'
  surface-container-high: '#e9e8e4'
  surface-container-highest: '#e3e2df'
  on-surface: '#1b1c1a'
  on-surface-variant: '#424843'
  inverse-surface: '#2f312e'
  inverse-on-surface: '#f2f1ed'
  outline: '#727972'
  outline-variant: '#c2c8c0'
  surface-tint: '#466550'
  primary: '#163422'
  on-primary: '#ffffff'
  primary-container: '#2d4b37'
  on-primary-container: '#99baa1'
  inverse-primary: '#adcfb4'
  secondary: '#7d562d'
  on-secondary: '#ffffff'
  secondary-container: '#ffca98'
  on-secondary-container: '#7a532a'
  tertiary: '#3c2c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#574200'
  on-tertiary-container: '#d2ae57'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c8ebd0'
  primary-fixed-dim: '#adcfb4'
  on-primary-fixed: '#022110'
  on-primary-fixed-variant: '#2f4d39'
  secondary-fixed: '#ffdcbd'
  secondary-fixed-dim: '#f0bd8b'
  on-secondary-fixed: '#2c1600'
  on-secondary-fixed-variant: '#623f18'
  tertiary-fixed: '#ffdf96'
  tertiary-fixed-dim: '#e7c268'
  on-tertiary-fixed: '#251a00'
  on-tertiary-fixed-variant: '#5a4400'
  background: '#faf9f5'
  on-background: '#1b1c1a'
  surface-variant: '#e3e2df'
  moss-dark: '#1B2E22'
  petal-pink: '#F4D3D3'
  earth-taupe: '#8D7B68'
  canvas-white: '#FDFCF8'
  ink-black: '#1A1A1A'
typography:
  display-lg:
    fontFamily: EB Garamond
    fontSize: 48px
    fontWeight: '500'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: EB Garamond
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: EB Garamond
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
  headline-md:
    fontFamily: EB Garamond
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  caption:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style

This design system is built for a high-end, modern florist experience that bridges the gap between traditional horticulture and contemporary luxury. The brand personality is organic, sophisticated, and intentional, targeting an audience that appreciates the artistry of floral design as much as the plants themselves.

The aesthetic follows a **Minimalist-Tactile** hybrid approach. We utilize heavy whitespace and a refined color palette to create a "gallery" feel for product photography, while incorporating subtle paper-like textures and soft shadows to evoke the physical sensation of high-quality florist wrapping and stationery. The goal is to evoke a sense of calm, freshness, and artisanal quality.

## Colors

The palette is rooted in a "Forest and Flora" concept. The primary color is a deep, sophisticated green that serves as the anchor for the brand, representing life and density. The secondary color is a warm, earthy terracotta that provides a grounded, artisanal contrast.

- **Primary (Deep Forest):** Use for primary buttons, headers, and brand-heavy backgrounds.
- **Secondary (Earth):** Use for accents, highlights, and secondary calls to action.
- **Neutral (Canvas):** This is the foundation of the UI, replacing pure white with a slightly warm, paper-like off-white to reduce eye strain and feel more organic.
- **Named Colors:** Use "Petal Pink" sparingly for seasonal promotions or soft notification states, and "Ink Black" for all primary body text to maintain high legibility without the harshness of true black.

## Typography

The typographic strategy pairs a classical, literary serif with a sharp, contemporary sans-serif to reflect the balance of heritage and modern design.

- **Headlines:** Use **EB Garamond**. It provides the "editorial luxury" feel essential for a high-end florist. Headlines should use medium weights to ensure the delicate serifs remain visible against botanical imagery.
- **Body & UI:** Use **Hanken Grotesk**. This font provides a clean, neutral counterpoint to the serif, ensuring high readability for product descriptions and checkout flows.
- **Styling Note:** Use `label-md` for small headers or category tags, always in uppercase with increased letter spacing to create a rhythmic, architectural feel.

## Layout & Spacing

The layout philosophy follows a **Fixed Grid** on desktop and a **Fluid Fluid** on mobile, emphasizing "breathable luxury." We use a 12-column grid to allow for asymmetrical arrangements of text and imagery, mimicking the natural arrangement of a bouquet.

- **Desktop:** 12 columns, 24px gutters, with a maximum container width of 1280px. Use large 80px-120px vertical sections to separate different content types (e.g., Hero to Featured Collection).
- **Mobile:** 4 columns, 16px gutters. Elements should stack vertically, but maintain generous internal padding within cards to avoid a "cramped" feel.
- **Alignment:** Center-align serif headlines for a formal, editorial look. Left-align body text for optimal readability.

## Elevation & Depth

To maintain a sophisticated and organic feel, this design system avoids heavy shadows. Instead, it uses **Tonal Layers** and **Soft Ambient Occlusion**.

- **Surfaces:** Use subtle shifts in background color (e.g., moving from `canvas-white` to a very light sage) to define different sections.
- **Shadows:** When necessary (such as for floating carts or product cards on hover), use a very large blur radius (30px+) with low opacity (8-10%) and a slight green-tinted shadow color (`#1B2E22`). This makes the element feel like it is resting softly on paper rather than floating in digital space.
- **Borders:** Use thin, 1px lines in `earth-taupe` at 20% opacity for horizontal separators to maintain structure without introducing visual clutter.

## Shapes

The shape language is primarily **Soft and Elegant**. While sharp edges feel too aggressive for a botanical brand, overly rounded "pill" shapes feel too tech-oriented. 

- **Standard Radius:** 4px (Soft) for buttons, input fields, and small cards. This provides a hint of approachability while maintaining a clean, professional edge.
- **Imagery:** Large hero images and product shots should maintain sharp corners to emphasize the "editorial" and "fine art" nature of the photography. 
- **Icons:** Use light-weight (2pt stroke) icons with rounded caps to match the soft corners of the UI.

## Components

### Buttons
Primary buttons use the `moss-dark` background with `canvas-white` text. They are rectangular with a 4px corner radius. Secondary buttons should be "ghost" style with a 1px `earth-taupe` border and a subtle hover state that fills the background with a 5% taupe tint.

### Cards
Product cards are borderless. The depth is created through the imagery itself. On hover, the image should slightly scale (1.05x) and a subtle, tinted shadow should appear. Product titles should be in `body-md` bold, with prices in the `EB Garamond` serif font.

### Input Fields
Inputs are minimalist, consisting of a bottom border (1px `earth-taupe`) that transitions to a full `moss-dark` border on focus. Labels should be small, uppercase, and positioned above the field.

### Chips & Tags
Use for flower types or scent profiles. These should have a `petal-pink` or light green background with dark text and a pill shape to distinguish them from actionable buttons.

### Navigation
The navigation should be airy. Use the serif font for the logo and the sans-serif for menu items. Include a "Utility Bar" at the very top in a contrasting earthy tone for shipping updates or location selection.